import Demo from "@/components/Demo";
import Header from "@/components/Header";

const index = () => {
  return (
    <>
      <Header />
      <Demo />
    </>
  );
};

export default index;
